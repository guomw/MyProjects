﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Data
{
    internal class DataArrayString : DataArray<string[]>
    {
    }
}
