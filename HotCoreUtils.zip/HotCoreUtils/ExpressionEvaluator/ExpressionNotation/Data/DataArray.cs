﻿namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Data
{
    internal abstract class DataArray<T> : DataValue<T>
    {
    }
}
