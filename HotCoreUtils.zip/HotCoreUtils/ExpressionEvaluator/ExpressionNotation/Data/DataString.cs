﻿namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Data
{
    internal class DataString : DataValue<string>
    {
    }
}
