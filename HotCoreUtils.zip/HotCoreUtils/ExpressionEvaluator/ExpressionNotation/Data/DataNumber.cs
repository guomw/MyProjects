﻿namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Data
{
    internal class DataNumber : DataValue<decimal>
    {
    }
}
