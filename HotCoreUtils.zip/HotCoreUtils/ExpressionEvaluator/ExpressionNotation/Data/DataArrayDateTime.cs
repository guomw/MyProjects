﻿using System;

namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Data
{
    internal class DataArrayDateTime : DataArray<DateTime[]>
    {
    }
}
