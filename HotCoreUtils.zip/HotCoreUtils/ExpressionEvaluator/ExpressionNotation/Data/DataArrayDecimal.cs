﻿namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Data
{
    internal class DataArrayDecimal : DataArray<decimal[]>
    {
    }
}
