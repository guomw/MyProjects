﻿using System;

namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.LogicalOperation
{
    internal class LogicalOperatorNot : LogicalOperator
    {      
    }
}
