﻿using System;
using System.Collections.Generic;

namespace HotCoreUtils.ExpressionEvaluator.ExpressionNotation.Typographic
{
    internal abstract class Parenthesis : ExpressionNotationToken
    {

    }
}
