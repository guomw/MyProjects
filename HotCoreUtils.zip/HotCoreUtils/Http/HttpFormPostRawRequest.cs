namespace HotCoreUtils.Http
{
    public class HttpFormPostRawRequest : HttpFormGetRequest
    {
        public string Data
        {
            get;
            set;
        }
    }
}